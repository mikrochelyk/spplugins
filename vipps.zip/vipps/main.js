const requestURL = 'https://api.vipps.no'

function pay(client_id, client_secret, merchantId) {
    const bearer = getAccessToken(client_id, client_secret);
    let order_id = initiatePayment(bearer, merchantId);
    capturePayment(bearer, order_id, merchantId);
    getDetails(order_id, merchantId);
}

async function sendRequest(method, url, data = {}) {
    if (method == "GET") {
        let res = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
        });

        return await res.json();
    }
    let response = await fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return await response.json();
}

function getAccessToken(client_id, client_secret) {
    sendRequest('POST', requestURL + '/accesstoken/get', {
            'client_id': client_id,
            'client_secret': client_secret,
            'Ocp-Apim-Subscription-Key': '0f14ebcab0ec4b29ae0cb90d91b4a84a'
        })
        .then((data) => {
            console.log(data);
        });
}

function initiatePayment(bearer, merchantId) {
    sendRequest('POST', requestURL + '/ecomm/v2/payments', {
            'Authorization': bearer, // Authorization - access token из прошлого метода
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': '0f14ebcab0ec4b29ae0cb90d91b4a84a',
            'Merchant-Serial-Number': merchantId
        })
        .then((data) => {
            console.log(data);
            return data['order_id'];
        });
}

function capturePayment(bearer, order_id, merchantId) {
    sendRequest('POST', requestURL + '/ecomm/v2/payments/' + order_id + '/capture', {
            'orderId': order_id, // в url orderID получается из прошлого метода
            'Authorization': bearer,
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': '0f14ebcab0ec4b29ae0cb90d91b4a84a',
            'X-Request-Id': 'fagwqgasgasdgasiko', // X-Request-Id - любое произвольное значение до 40 символов
            'Merchant-Serial-Number': merchantId
        })
        .then((data) => {
            console.log(data);
        });
}

function cancelPayment(merchantId, order_id) {
    sendRequest('PUT', requestURL + '/ecomm/v2/payments/' + order_id + '/cancel', {
            'orderId': order_id,
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': '0f14ebcab0ec4b29ae0cb90d91b4a84a',
            'Merchant-Serial-Number': merchantId
        })
        .then((data) => {
            console.log(data);
        });
}

function doARefund(order_id, merchantId) {
    sendRequest('PUT', requestURL + '/ecomm/v2/payments/' + order_id + '/refund', {
            'orderId': order_id,
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': '0f14ebcab0ec4b29ae0cb90d91b4a84a',
            'X-Request-Id': 'fagwqgasgasdgasiko',
            'Merchant-Serial-Number': merchantId
        })
        .then((data) => {
            console.log(data);
        });
}

function getDetails(bearer, order_id, merchantId) {
    sendRequest('GET', requestURL + '/ecomm/v2/payments/' + order_id + '/details', {
            'orderId': order_id,
            'Authorization': bearer,
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': '0f14ebcab0ec4b29ae0cb90d91b4a84a',
            'Merchant-Serial-Number': merchantId
        })
        .then((data) => {
            console.log(data);
        });
}